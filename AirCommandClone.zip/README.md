# Air Command Clone (v0.1)

Step 1: floating bubble + shortcut panel + in-app "Shortcuts" page.
Menu items only show a toast for now (features are added one by one).

Build: push to GitHub (main branch) -> Actions -> "Build APK" -> download artifact `AirCommandClone-debug`.
