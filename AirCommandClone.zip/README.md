# Air Command Clone (v0.3)

- Bubble + shortcut panel (round icons for every item, light/dark)
- Shortcuts page with Settings button (top right)
- Settings: theme, bubble glow on/off, bubble size, icon size, animation style, shortcut targets (pick real apps/screens)
- Control Center tile to turn the bubble on/off

Build: push to GitHub -> Actions -> download artifact AirCommandClone-debug.
