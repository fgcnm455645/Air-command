package com.aircmd.clone

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    private lateinit var c: AppColors
    private var darkAtBuild = false
    private lateinit var targetsHost: LinearLayout

    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun rounded(color: Int, radiusDp: Float): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun dialogTheme(): Int =
        if (c.dark) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        c = AppColors.of(this)
        darkAtBuild = c.dark
        AppColors.styleWindow(this, c)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(c.page)

        val header = LinearLayout(this)
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(12f), 0, dp(12f), 0)
        val back = ImageView(this)
        back.setImageResource(R.drawable.ic_back)
        back.setColorFilter(c.text)
        back.setPadding(dp(10f), dp(10f), dp(10f), dp(10f))
        back.setOnClickListener { finish() }
        header.addView(back, lp(dp(44f), dp(44f)))
        val title = TextView(this)
        title.text = "Settings"
        title.textSize = 20f
        title.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        title.setTextColor(c.text)
        title.setPadding(dp(8f), 0, 0, 0)
        header.addView(title, lp(wrap, wrap))
        root.addView(header, lp(match, dp(56f)))

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16f), 0, dp(16f), dp(28f))

        // Appearance
        content.addView(sectionTitle("Appearance"), lp(match, wrap))
        val appearance = card()
        val themeValue = TextView(this)
        appearance.addView(
            valueRow("Theme", null, themeValue) { chooseTheme() },
            lp(match, wrap)
        )
        themeValue.text = themeName()
        content.addView(appearance, lp(match, wrap))

        // Bubble
        content.addView(sectionTitle("Bubble"), lp(match, wrap))
        val bubble = card()
        bubble.addView(
            switchRow("Colorful glow", "Animated glow around the bubble", Prefs.glow(this)) { on ->
                Prefs.setGlow(this, on)
                reloadBubble()
            },
            lp(match, wrap)
        )
        bubble.addView(divider(), lp(match, 1))
        bubble.addView(
            switchRow("Hide when idle", "Shrink and fade the bubble when it isn't used", Prefs.idleHide(this)) { on ->
                Prefs.setIdleHide(this, on)
                reloadBubble()
            },
            lp(match, wrap)
        )
        bubble.addView(divider(), lp(match, 1))
        bubble.addView(
            sliderRow("Bubble size", 70, 140, Prefs.bubbleScale(this), "%") { v ->
                Prefs.setBubbleScale(this, v)
                reloadBubble()
            },
            lp(match, wrap)
        )
        content.addView(bubble, lp(match, wrap))

        // Menu
        content.addView(sectionTitle("Menu"), lp(match, wrap))
        val menu = card()
        val animValue = TextView(this)
        menu.addView(
            valueRow("Animation style", null, animValue) { chooseAnim(animValue) },
            lp(match, wrap)
        )
        animValue.text = animName()
        menu.addView(divider(), lp(match, 1))
        menu.addView(
            sliderRow("Icon size", 36, 50, Prefs.iconSize(this), "dp") { v -> Prefs.setIconSize(this, v) },
            lp(match, wrap)
        )
        menu.addView(divider(), lp(match, 1))
        menu.addView(
            sliderRow("Panel size", 50, 110, Prefs.panelScale(this), "%") { v -> Prefs.setPanelScale(this, v) },
            lp(match, wrap)
        )
        content.addView(menu, lp(match, wrap))

        // Targets
        content.addView(sectionTitle("Shortcut targets"), lp(match, wrap))
        val hint = TextView(this)
        hint.text = "Choose which installed app (or screen) each shortcut opens."
        hint.textSize = 12f
        hint.setTextColor(c.text2)
        hint.setPadding(dp(4f), 0, dp(4f), dp(8f))
        content.addView(hint, lp(match, wrap))
        targetsHost = card()
        content.addView(targetsHost, lp(match, wrap))
        refreshTargets()

        scroll.addView(content)
        root.addView(scroll, lp(match, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (AppColors.isDark(this) != darkAtBuild) recreate()
    }

    // ---------- building blocks ----------
    private fun sectionTitle(text: String): View {
        val t = TextView(this)
        t.text = text
        t.textSize = 14f
        t.setTextColor(c.text2)
        t.setPadding(dp(4f), dp(20f), 0, dp(8f))
        return t
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.background = rounded(c.card, 20f)
        return l
    }

    private fun divider(): View {
        val v = View(this)
        v.setBackgroundColor(c.divider)
        return v
    }

    private fun titleCol(title: String, subtitle: String?): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t1 = TextView(this)
        t1.text = title
        t1.textSize = 16f
        t1.setTextColor(c.text)
        col.addView(t1, lp(wrap, wrap))
        if (subtitle != null) {
            val t2 = TextView(this)
            t2.text = subtitle
            t2.textSize = 12f
            t2.setTextColor(c.text2)
            col.addView(t2, lp(wrap, wrap))
        }
        return col
    }

    private fun valueRow(title: String, subtitle: String?, value: TextView, onClick: () -> Unit): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(18f), dp(14f), dp(18f), dp(14f))
        r.addView(titleCol(title, subtitle), lp(0, wrap, 1f))
        value.textSize = 14f
        value.setTextColor(c.text2)
        r.addView(value, lp(wrap, wrap))
        r.setOnClickListener { onClick() }
        return r
    }

    private fun switchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(18f), dp(12f), dp(14f), dp(12f))
        r.addView(titleCol(title, subtitle), lp(0, wrap, 1f))
        val sw = Switch(this)
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
        r.addView(sw, lp(wrap, wrap))
        r.setOnClickListener { sw.toggle() }
        return r
    }

    private fun sliderRow(title: String, min: Int, max: Int, value: Int, unit: String, onDone: (Int) -> Unit): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(dp(18f), dp(14f), dp(18f), dp(8f))

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(titleCol(title, null), lp(0, wrap, 1f))
        val vt = TextView(this)
        vt.textSize = 14f
        vt.setTextColor(c.text2)
        vt.text = "$value$unit"
        top.addView(vt, lp(wrap, wrap))
        r.addView(top, lp(match, wrap))

        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = value - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                vt.text = "${progress + min}$unit"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                onDone((seekBar?.progress ?: 0) + min)
            }
        })
        r.addView(sb, lp(match, wrap))
        return r
    }

    // ---------- actions ----------
    private fun reloadBubble() {
        if (Prefs.enabled(this) && Settings.canDrawOverlays(this)) {
            val i = Intent(this, BubbleService::class.java)
            i.action = "reload"
            startForegroundService(i)
        }
    }

    private fun themeName(): String = arrayOf("System default", "Light", "Dark")[Prefs.theme(this)]

    private fun chooseTheme() {
        val names = arrayOf("System default", "Light", "Dark")
        AlertDialog.Builder(this, dialogTheme())
            .setTitle("Theme")
            .setSingleChoiceItems(names, Prefs.theme(this)) { d, which ->
                Prefs.setTheme(this, which)
                d.dismiss()
                recreate()
            }
            .show()
    }

    private fun animName(): String =
        if (Prefs.animStyle(this) == 1) "Smart Touch" else "Air Command"

    private fun chooseAnim(valueView: TextView) {
        val names = arrayOf("Air Command (panel)", "Smart Touch (floating items)")
        AlertDialog.Builder(this, dialogTheme())
            .setTitle("Animation style")
            .setSingleChoiceItems(names, Prefs.animStyle(this)) { d, which ->
                Prefs.setAnimStyle(this, which)
                valueView.text = animName()
                d.dismiss()
            }
            .show()
    }

    private fun targetText(id: String): String {
        val t = Targets.get(this, id) ?: return "Not set"
        val pkg = t.substringBefore("/")
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        return if (t.contains("/")) "$label (screen)" else label
    }

    private fun refreshTargets() {
        targetsHost.removeAllViews()
        val list = Features.all + Features.samsungApps
        for ((index, f) in list.withIndex()) {
            if (index > 0) targetsHost.addView(divider(), lp(match, 1))
            val r = LinearLayout(this)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(18f), dp(10f), dp(18f), dp(10f))
            val iv = ImageView(this)
            iv.setImageDrawable(featureIcon(this, f, dp(36f)))
            r.addView(iv, lp(dp(36f), dp(36f)))
            val col = titleCol(f.label, null)
            col.setPadding(dp(14f), 0, 0, 0)
            r.addView(col, lp(0, wrap, 1f))
            val v = TextView(this)
            v.text = targetText(f.id)
            v.textSize = 13f
            v.setTextColor(c.text2)
            r.addView(v, lp(wrap, wrap))
            r.setOnClickListener { pickApp(f) }
            targetsHost.addView(r, lp(match, wrap))
        }
    }

    private fun launchableApps(): List<ItemInfo> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { ItemInfo(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
    }

    private fun pickApp(f: Feature) {
        val apps = launchableApps()
        val dctx = ContextThemeWrapper(this, dialogTheme())
        val lv = ListView(dctx)
        lv.adapter = object : BaseAdapter() {
            override fun getCount(): Int = apps.size
            override fun getItem(position: Int): Any = apps[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val info = apps[position]
                val r = LinearLayout(dctx)
                r.gravity = Gravity.CENTER_VERTICAL
                r.setPadding(dp(20f), dp(8f), dp(20f), dp(8f))
                val iv = ImageView(dctx)
                iv.setImageDrawable(info.icon)
                r.addView(iv, LinearLayout.LayoutParams(dp(36f), dp(36f)))
                val tv = TextView(dctx)
                tv.text = info.label
                tv.textSize = 15f
                tv.setPadding(dp(14f), 0, 0, 0)
                r.addView(tv, LinearLayout.LayoutParams(wrap, wrap))
                return r
            }
        }
        val dlg = AlertDialog.Builder(this, dialogTheme())
            .setTitle(f.label)
            .setView(lv)
            .setNegativeButton("Reset") { _, _ ->
                Prefs.setTarget(this, f.id, null)
                refreshTargets()
            }
            .create()
        lv.setOnItemClickListener { _, _, pos, _ ->
            dlg.dismiss()
            pickScreen(f, apps[pos].id)
        }
        dlg.show()
    }

    private fun pickScreen(f: Feature, pkg: String) {
        val pm = packageManager
        val acts = try {
            pm.getPackageInfo(pkg, PackageManager.GET_ACTIVITIES).activities
                ?.filter { it.exported && it.enabled } ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
        val names = ArrayList<String>()
        val targets = ArrayList<String>()
        names.add("Open the app")
        targets.add(pkg)
        for (a in acts) {
            names.add(a.loadLabel(pm).toString() + "  ·  " + a.name.substringAfterLast('.'))
            targets.add(pkg + "/" + a.name)
        }
        AlertDialog.Builder(this, dialogTheme())
            .setTitle(f.label)
            .setItems(names.toTypedArray()) { _, which ->
                Prefs.setTarget(this, f.id, targets[which])
                refreshTargets()
            }
            .show()
    }
}
