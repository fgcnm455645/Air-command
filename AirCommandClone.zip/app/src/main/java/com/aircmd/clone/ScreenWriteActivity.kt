package com.aircmd.clone

import android.app.Activity
import android.content.ContentValues
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast

/**
 * Screen write: a black page you write on. Layout copied from the original
 * (back, Done, more at the top; pen / eraser / undo / redo pill at the bottom).
 */
class ScreenWriteActivity : Activity() {
    private lateinit var write: WriteView
    private lateinit var done: TextView
    private lateinit var pill: LinearLayout
    private lateinit var penBtn: ImageView
    private lateinit var eraserBtn: ImageView
    private lateinit var undoBtn: ImageView
    private lateinit var redoBtn: ImageView

    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        write = WriteView(this)
        root.addView(write, FrameLayout.LayoutParams(match, match))

        // top bar
        val back = ImageView(this)
        back.setImageResource(R.drawable.ic_back)
        back.setColorFilter(Color.WHITE)
        back.setPadding(dp(10f), dp(10f), dp(10f), dp(10f))
        back.setOnClickListener { finish() }
        val backLp = FrameLayout.LayoutParams(dp(44f), dp(44f), Gravity.TOP or Gravity.START)
        backLp.topMargin = dp(6f)
        backLp.leftMargin = dp(14f)
        root.addView(back, backLp)

        done = TextView(this)
        done.text = "Done"
        done.textSize = 17f
        done.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        done.setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
        done.setOnClickListener { if (write.strokes.isNotEmpty()) saveImage() }
        val doneLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END
        )
        doneLp.topMargin = dp(8f)
        doneLp.rightMargin = dp(52f)
        root.addView(done, doneLp)

        val more = ImageView(this)
        more.setImageResource(R.drawable.ic_sw_dots)
        more.setColorFilter(0xFFBDBDBD.toInt())
        more.setPadding(dp(10f), dp(10f), dp(10f), dp(10f))
        more.setOnClickListener {
            val pm = PopupMenu(this, more)
            pm.menu.add("Clear all")
            pm.setOnMenuItemClickListener {
                write.clearAll()
                true
            }
            pm.show()
        }
        val moreLp = FrameLayout.LayoutParams(dp(44f), dp(44f), Gravity.TOP or Gravity.END)
        moreLp.topMargin = dp(6f)
        moreLp.rightMargin = dp(8f)
        root.addView(more, moreLp)

        // bottom pill: pen, eraser, undo, redo
        pill = LinearLayout(this)
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.setColor(0xFF3C3C3C.toInt())
        bg.cornerRadius = dp(27f).toFloat()
        pill.background = bg
        penBtn = tool(R.drawable.ic_sw_pen_fill) { setEraser(false) }
        eraserBtn = tool(R.drawable.ic_sw_eraser_line) { setEraser(true) }
        undoBtn = tool(R.drawable.ic_sw_undo) { write.undo() }
        redoBtn = tool(R.drawable.ic_sw_redo) { write.redo() }
        pill.addView(penBtn, LinearLayout.LayoutParams(dp(54f), dp(54f)))
        pill.addView(eraserBtn, LinearLayout.LayoutParams(dp(54f), dp(54f)))
        pill.addView(undoBtn, LinearLayout.LayoutParams(dp(54f), dp(54f)))
        pill.addView(redoBtn, LinearLayout.LayoutParams(dp(54f), dp(54f)))
        val pillLp = FrameLayout.LayoutParams(dp(216f), dp(54f), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        pillLp.bottomMargin = dp(28f)
        root.addView(pill, pillLp)

        write.onChange = { refreshUi() }
        write.onTouching = { t -> pill.animate().alpha(if (t) 0.12f else 1f).setDuration(150).start() }
        setContentView(root)
        refreshUi()
    }

    private fun tool(res: Int, onClick: () -> Unit): ImageView {
        val iv = ImageView(this)
        iv.setImageResource(res)
        iv.setColorFilter(Color.WHITE)
        iv.setPadding(dp(15f), dp(15f), dp(15f), dp(15f))
        iv.setOnClickListener { onClick() }
        return iv
    }

    private fun setEraser(on: Boolean) {
        write.eraser = on
        penBtn.setImageResource(if (on) R.drawable.ic_sw_pen_line else R.drawable.ic_sw_pen_fill)
        eraserBtn.setImageResource(if (on) R.drawable.ic_sw_eraser_fill else R.drawable.ic_sw_eraser_line)
    }

    private fun refreshUi() {
        val has = write.strokes.isNotEmpty()
        done.setTextColor(if (has) Color.WHITE else 0xFF6B6B6B.toInt())
        undoBtn.alpha = if (write.canUndo()) 1f else 0.4f
        redoBtn.alpha = if (write.canRedo()) 1f else 0.4f
    }

    private fun saveImage() {
        if (Build.VERSION.SDK_INT < 29) {
            Toast.makeText(this, "Saving needs Android 10 or newer", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val values = ContentValues()
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "ScreenWrite_" + System.currentTimeMillis() + ".png")
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AirCommand")
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) {
                Toast.makeText(this, "Couldn't save", Toast.LENGTH_SHORT).show()
                return
            }
            val bmp = write.toBitmap()
            contentResolver.openOutputStream(uri)?.use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "Saved to Pictures/AirCommand", Toast.LENGTH_SHORT).show()
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't save", Toast.LENGTH_SHORT).show()
        }
    }
}
