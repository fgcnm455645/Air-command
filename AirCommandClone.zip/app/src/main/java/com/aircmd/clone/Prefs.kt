package com.aircmd.clone

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("air", Context.MODE_PRIVATE)

    fun items(c: Context): MutableList<String> {
        val s = sp(c).getString("items", null) ?: return Features.all.map { it.id }.toMutableList()
        return if (s.isEmpty()) mutableListOf() else s.split(",").toMutableList()
    }

    fun setItems(c: Context, list: List<String>) {
        sp(c).edit().putString("items", list.joinToString(",")).apply()
    }

    fun enabled(c: Context): Boolean = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("enabled", v).apply() }

    fun bubbleY(c: Context, def: Int): Int = sp(c).getInt("by", def)
    fun bubbleRight(c: Context): Boolean = sp(c).getBoolean("br", true)
    fun setBubble(c: Context, y: Int, right: Boolean) {
        sp(c).edit().putInt("by", y).putBoolean("br", right).apply()
    }

    // 0 = system, 1 = light, 2 = dark
    fun theme(c: Context): Int = sp(c).getInt("theme", 0)
    fun setTheme(c: Context, v: Int) { sp(c).edit().putInt("theme", v).apply() }

    fun glow(c: Context): Boolean = sp(c).getBoolean("glow", true)
    fun setGlow(c: Context, v: Boolean) { sp(c).edit().putBoolean("glow", v).apply() }

    // menu icon size in dp (36..50)
    fun iconSize(c: Context): Int = sp(c).getInt("iconSize", 46)
    fun setIconSize(c: Context, v: Int) { sp(c).edit().putInt("iconSize", v).apply() }

    // bubble scale in percent (70..140)
    fun bubbleScale(c: Context): Int = sp(c).getInt("bubbleScale", 100)
    fun setBubbleScale(c: Context, v: Int) { sp(c).edit().putInt("bubbleScale", v).apply() }

    // 0 = Air Command (default); more styles later
    fun animStyle(c: Context): Int = sp(c).getInt("animStyle", 0)
    fun setAnimStyle(c: Context, v: Int) { sp(c).edit().putInt("animStyle", v).apply() }

    fun target(c: Context, id: String): String? = sp(c).getString("t_$id", null)
    fun setTarget(c: Context, id: String, v: String?) {
        val e = sp(c).edit()
        if (v == null) e.remove("t_$id") else e.putString("t_$id", v)
        e.apply()
    }
}
