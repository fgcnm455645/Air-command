package com.aircmd.clone

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("air", Context.MODE_PRIVATE)

    fun items(c: Context): MutableList<String> {
        val s = sp(c).getString("items", null) ?: return Features.all.map { it.id }.toMutableList()
        return if (s.isEmpty()) mutableListOf() else s.split(",").toMutableList()
    }

    fun setItems(c: Context, list: List<String>) {
        sp(c).edit().putString("items", list.joinToString(",")).apply()
    }

    fun enabled(c: Context): Boolean = sp(c).getBoolean("enabled", false)

    fun setEnabled(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("enabled", v).apply()
    }

    fun bubbleY(c: Context, def: Int): Int = sp(c).getInt("by", def)

    fun bubbleRight(c: Context): Boolean = sp(c).getBoolean("br", true)

    fun setBubble(c: Context, y: Int, right: Boolean) {
        sp(c).edit().putInt("by", y).putBoolean("br", right).apply()
    }
}
