package com.aircmd.clone

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Control Center / Quick Settings tile that turns the bubble on and off. */
class AirTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        if (!Settings.canDrawOverlays(this)) {
            openApp()
            return
        }
        val on = !Prefs.enabled(this)
        Prefs.setEnabled(this, on)
        val i = Intent(this, BubbleService::class.java)
        if (on) startForegroundService(i) else stopService(i)
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        val on = Prefs.enabled(this) && Settings.canDrawOverlays(this)
        t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.updateTile()
    }

    private fun openApp() {
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
        } else {
            startActivityAndCollapse(i)
        }
    }
}
