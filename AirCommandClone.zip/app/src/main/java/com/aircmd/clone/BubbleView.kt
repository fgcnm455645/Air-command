package com.aircmd.clone

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.sin

/**
 * Floating bubble, built from the structure found in the original app:
 * blue + green blurred ovals (60dp, blur 7dp) drifting behind a 48dp dark circle with the pen glyph.
 */
class BubbleView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val radius = 24f * d

    private val bluePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF308FE6.toInt()
        alpha = (255 * 0.36f).toInt()
        maskFilter = BlurMaskFilter(7f * d, BlurMaskFilter.Blur.NORMAL)
    }
    private val greenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF3DDAC8.toInt()
        alpha = (255 * 0.62f).toInt()
        maskFilter = BlurMaskFilter(7f * d, BlurMaskFilter.Blur.NORMAL)
    }
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF252528.toInt()
    }
    private val pen = ctx.getDrawable(R.drawable.ic_pen)!!

    private var phase = 0f
    private var pressScale = 1f
    private var loop: ValueAnimator? = null

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val a = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat())
        a.duration = 4000
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
        a.start()
        loop = a
    }

    override fun onDetachedFromWindow() {
        loop?.cancel()
        super.onDetachedFromWindow()
    }

    fun press(down: Boolean) {
        val a = ValueAnimator.ofFloat(pressScale, if (down) 0.9f else 1f)
        a.duration = 100
        a.addUpdateListener {
            pressScale = it.animatedValue as Float
            invalidate()
        }
        a.start()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val dx = sin(phase) * 3f * d
        val dy = cos(phase) * 4f * d
        canvas.drawCircle(cx + dx, cy + dy, radius, bluePaint)
        canvas.drawCircle(cx - dx, cy - dy, radius, greenPaint)

        canvas.save()
        canvas.scale(pressScale, pressScale, cx, cy)
        canvas.drawCircle(cx, cy, radius, bodyPaint)
        pen.setBounds((cx - radius).toInt(), (cy - radius).toInt(), (cx + radius).toInt(), (cy + radius).toInt())
        pen.draw(canvas)
        canvas.restore()
    }
}
