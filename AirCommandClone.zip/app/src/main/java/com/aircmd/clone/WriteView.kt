package com.aircmd.clone

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Black writing page. Pen draws white strokes; the eraser removes the WHOLE stroke it touches.
 */
class WriteView(ctx: Context) : View(ctx) {
    class Stroke(val path: Path, val xs: ArrayList<Float>, val ys: ArrayList<Float>)
    class Op(val add: Boolean, val stroke: Stroke, val index: Int)

    val strokes = ArrayList<Stroke>()
    private val undoStack = ArrayList<Op>()
    private val redoStack = ArrayList<Op>()

    var eraser = false
    var onChange: (() -> Unit)? = null
    var onTouching: ((Boolean) -> Unit)? = null

    private val d = ctx.resources.displayMetrics.density
    private val penPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 3.2f * d
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val cursorLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8A8A8A.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
    }
    private val cursorFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x22FFFFFF
        style = Paint.Style.FILL
    }
    private val eraserR = 14f * d

    private var cur: Stroke? = null
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false
    private var erasing = false
    private var ex = 0f
    private var ey = 0f

    fun canUndo() = undoStack.isNotEmpty()
    fun canRedo() = redoStack.isNotEmpty()

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                onTouching?.invoke(true)
                if (eraser) {
                    erasing = true
                    ex = x
                    ey = y
                    eraseAt(x, y)
                } else {
                    startStroke(x, y)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (eraser) {
                    ex = x
                    ey = y
                    eraseAt(x, y)
                } else {
                    for (i in 0 until e.historySize) addPoint(e.getHistoricalX(i), e.getHistoricalY(i))
                    addPoint(x, y)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (eraser) erasing = false else endStroke()
                onTouching?.invoke(false)
            }
        }
        invalidate()
        return true
    }

    private fun startStroke(x: Float, y: Float) {
        val p = Path()
        p.moveTo(x, y)
        val s = Stroke(p, arrayListOf(x), arrayListOf(y))
        cur = s
        lastX = x
        lastY = y
        moved = false
    }

    private fun addPoint(x: Float, y: Float) {
        val s = cur ?: return
        if (hypot(x - lastX, y - lastY) < 1.5f * d) return
        s.path.quadTo(lastX, lastY, (x + lastX) / 2f, (y + lastY) / 2f)
        s.xs.add(x)
        s.ys.add(y)
        lastX = x
        lastY = y
        moved = true
    }

    private fun endStroke() {
        val s = cur ?: return
        if (moved) s.path.lineTo(lastX, lastY) else s.path.lineTo(lastX + 0.01f, lastY)
        strokes.add(s)
        undoStack.add(Op(true, s, strokes.size - 1))
        redoStack.clear()
        cur = null
        onChange?.invoke()
    }

    private fun segDist(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax
        val dy = by - ay
        val len2 = dx * dx + dy * dy
        if (len2 == 0f) return hypot(px - ax, py - ay)
        val t = max(0f, min(1f, ((px - ax) * dx + (py - ay) * dy) / len2))
        return hypot(px - (ax + t * dx), py - (ay + t * dy))
    }

    private fun hits(s: Stroke, x: Float, y: Float): Boolean {
        val r = eraserR + penPaint.strokeWidth / 2f
        if (s.xs.size == 1) return hypot(x - s.xs[0], y - s.ys[0]) <= r
        for (i in 0 until s.xs.size - 1) {
            if (segDist(x, y, s.xs[i], s.ys[i], s.xs[i + 1], s.ys[i + 1]) <= r) return true
        }
        return false
    }

    private fun eraseAt(x: Float, y: Float) {
        var changed = false
        for (i in strokes.indices.reversed()) {
            val s = strokes[i]
            if (hits(s, x, y)) {
                strokes.removeAt(i)
                undoStack.add(Op(false, s, i))
                changed = true
            }
        }
        if (changed) {
            redoStack.clear()
            onChange?.invoke()
        }
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val op = undoStack.removeAt(undoStack.size - 1)
        if (op.add) {
            strokes.remove(op.stroke)
        } else {
            strokes.add(min(op.index, strokes.size), op.stroke)
        }
        redoStack.add(op)
        onChange?.invoke()
        invalidate()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val op = redoStack.removeAt(redoStack.size - 1)
        if (op.add) {
            strokes.add(min(op.index, strokes.size), op.stroke)
        } else {
            strokes.remove(op.stroke)
        }
        undoStack.add(op)
        onChange?.invoke()
        invalidate()
    }

    fun clearAll() {
        if (strokes.isEmpty()) return
        for (i in strokes.indices.reversed()) undoStack.add(Op(false, strokes[i], i))
        strokes.clear()
        redoStack.clear()
        onChange?.invoke()
        invalidate()
    }

    private fun render(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        for (s in strokes) canvas.drawPath(s.path, penPaint)
        cur?.let { canvas.drawPath(it.path, penPaint) }
    }

    override fun onDraw(canvas: Canvas) {
        render(canvas)
        if (eraser && erasing) {
            canvas.drawCircle(ex, ey, eraserR, cursorFill)
            canvas.drawCircle(ex, ey, eraserR, cursorLine)
        }
    }

    fun toBitmap(): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        render(Canvas(bmp))
        return bmp
    }
}
