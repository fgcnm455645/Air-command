package com.aircmd.clone

import android.content.Context
import android.content.Intent

/** Which real app (or exported screen) each shortcut opens. Stored as "pkg" or "pkg/class". */
object Targets {
    private val defaults = mapOf(
        "create_note" to "com.samsung.android.app.notes",
        "view_notes" to "com.samsung.android.app.notes",
        "bixby_vision" to "com.samsung.android.visionintelligence"
    )

    fun get(ctx: Context, id: String): String? = Prefs.target(ctx, id) ?: defaults[id]

    fun intentFor(ctx: Context, target: String): Intent? {
        val i: Intent? = if (target.contains("/")) {
            val pkg = target.substringBefore("/")
            val cls = target.substringAfter("/")
            Intent().setClassName(pkg, cls)
        } else {
            ctx.packageManager.getLaunchIntentForPackage(target)
        }
        i?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return i
    }
}
