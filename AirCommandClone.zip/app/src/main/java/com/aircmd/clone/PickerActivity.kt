package com.aircmd.clone

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** Full page for choosing which app (or exported screen) a shortcut opens. */
class PickerActivity : Activity() {
    private lateinit var c: AppColors
    private lateinit var featureId: String
    private var all: List<ItemInfo> = emptyList()
    private val shown = ArrayList<ItemInfo>()
    private lateinit var adapter: BaseAdapter

    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        c = AppColors.of(this)
        AppColors.styleWindow(this, c)
        featureId = intent.getStringExtra("id") ?: run {
            finish()
            return
        }
        val label = intent.getStringExtra("label") ?: featureId

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(c.page)

        val header = LinearLayout(this)
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(12f), 0, dp(12f), 0)
        val back = ImageView(this)
        back.setImageResource(R.drawable.ic_back)
        back.setColorFilter(c.text)
        back.setPadding(dp(10f), dp(10f), dp(10f), dp(10f))
        back.setOnClickListener { finish() }
        header.addView(back, lp(dp(44f), dp(44f)))
        val titleCol = LinearLayout(this)
        titleCol.orientation = LinearLayout.VERTICAL
        titleCol.setPadding(dp(8f), 0, 0, 0)
        val t1 = TextView(this)
        t1.text = label
        t1.textSize = 20f
        t1.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t1.setTextColor(c.text)
        val t2 = TextView(this)
        t2.text = "Choose which app opens"
        t2.textSize = 12f
        t2.setTextColor(c.text2)
        titleCol.addView(t1, lp(wrap, wrap))
        titleCol.addView(t2, lp(wrap, wrap))
        header.addView(titleCol, lp(wrap, wrap))
        root.addView(header, lp(match, dp(60f)))

        val search = EditText(this)
        search.hint = "Search apps"
        search.setHintTextColor(c.text2)
        search.setTextColor(c.text)
        search.textSize = 15f
        search.setSingleLine(true)
        search.setPadding(dp(18f), dp(10f), dp(18f), dp(10f))
        val sbg = GradientDrawable()
        sbg.setColor(c.card)
        sbg.cornerRadius = dp(22f).toFloat()
        search.background = sbg
        val sLp = lp(match, wrap)
        sLp.setMargins(dp(16f), dp(4f), dp(16f), dp(8f))
        root.addView(search, sLp)

        val pm = packageManager
        val intentL = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        all = pm.queryIntentActivities(intentL, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { ItemInfo(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
        shown.addAll(all)

        val lv = ListView(this)
        lv.divider = null
        lv.setBackgroundColor(c.page)
        adapter = object : BaseAdapter() {
            // position 0 is the "Not set" row
            override fun getCount(): Int = shown.size + 1
            override fun getItem(position: Int): Any = position
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val r = LinearLayout(this@PickerActivity)
                r.gravity = Gravity.CENTER_VERTICAL
                r.setPadding(dp(20f), dp(9f), dp(20f), dp(9f))
                val tv = TextView(this@PickerActivity)
                tv.textSize = 16f
                tv.setTextColor(c.text)
                if (position == 0) {
                    tv.text = "Not set"
                    tv.setPadding(dp(50f), dp(8f), 0, dp(8f))
                } else {
                    val info = shown[position - 1]
                    val iv = ImageView(this@PickerActivity)
                    iv.setImageDrawable(info.icon)
                    r.addView(iv, lp(dp(38f), dp(38f)))
                    tv.text = info.label
                    tv.setPadding(dp(16f), 0, 0, 0)
                }
                r.addView(tv, lp(wrap, wrap))
                return r
            }
        }
        lv.adapter = adapter
        lv.setOnItemClickListener { _, _, pos, _ ->
            if (pos == 0) {
                Prefs.setTarget(this, featureId, null)
                finish()
            } else {
                pickScreen(shown[pos - 1].id)
            }
        }
        root.addView(lv, lp(match, 0, 1f))

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = (s?.toString() ?: "").trim().lowercase()
                shown.clear()
                shown.addAll(all.filter { it.label.lowercase().contains(q) })
                adapter.notifyDataSetChanged()
            }
        })
        setContentView(root)
    }

    private fun pickScreen(pkg: String) {
        val pm = packageManager
        val acts = try {
            pm.getPackageInfo(pkg, PackageManager.GET_ACTIVITIES).activities
                ?.filter { it.exported && it.enabled } ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
        val names = ArrayList<String>()
        val targets = ArrayList<String>()
        names.add("Open the app")
        targets.add(pkg)
        for (a in acts) {
            names.add(a.loadLabel(pm).toString() + "  ·  " + a.name.substringAfterLast('.'))
            targets.add(pkg + "/" + a.name)
        }
        val theme = if (c.dark) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert
        AlertDialog.Builder(this, theme)
            .setTitle("Open…")
            .setItems(names.toTypedArray()) { _, which ->
                Prefs.setTarget(this, featureId, targets[which])
                finish()
            }
            .show()
    }
}
