package com.aircmd.clone

data class Feature(val id: String, val label: String, val color: Int, val glyph: Int)

object Features {
    val all: List<Feature> = listOf(
        Feature("create_note", "Create note", 0xFFE33423.toInt(), R.drawable.ic_f_create_note),
        Feature("view_notes", "View all notes", 0xFFDD2B20.toInt(), R.drawable.ic_f_view_notes),
        Feature("smart_select", "Smart select", 0xFFFD584C.toInt(), R.drawable.ic_f_smart_select),
        Feature("screen_write", "Screen write", 0xFF6D69F1.toInt(), R.drawable.ic_f_screen_write),
        Feature("live_messages", "Live messages", 0xFF6E6FF1.toInt(), R.drawable.ic_f_live_messages),
        Feature("bixby_vision", "Bixby Vision", 0xFF30296C.toInt(), R.drawable.ic_f_bixby_vision),
        Feature("translate", "Translate", 0xFF385479.toInt(), R.drawable.ic_f_translate),
        Feature("magnify", "Magnify", 0xFF00A266.toInt(), R.drawable.ic_f_magnify),
        Feature("glance", "Glance", 0xFF18A80C.toInt(), R.drawable.ic_f_glance)
    )

    fun byId(id: String): Feature? = all.firstOrNull { it.id == id }
}
