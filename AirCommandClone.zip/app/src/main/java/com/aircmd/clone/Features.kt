package com.aircmd.clone

/** raster = the drawable is a full app icon (cropped to a circle), otherwise a glyph drawn on a colored circle. */
data class Feature(
    val id: String,
    val label: String,
    val color: Int,
    val glyph: Int,
    val raster: Boolean = false,
    val inset: Float = 0.2f
)

object Features {
    val all: List<Feature> = listOf(
        Feature("create_note", "Create note", 0xFFEE1F1F.toInt(), R.drawable.g_create_note),
        Feature("view_notes", "View all notes", 0xFFEE1F1F.toInt(), R.drawable.g_view_notes),
        Feature("smart_select", "Smart select", 0xFFE6E6E6.toInt(), R.drawable.g_smart_select),
        Feature("screen_write", "Screen write", 0xFF6D69F1.toInt(), R.drawable.g_screen_write, false, 0.26f),
        Feature("live_messages", "Live messages", 0xFF6E6FF1.toInt(), R.drawable.ic_f_live_messages),
        Feature("bixby_vision", "Bixby Vision", 0xFF30296C.toInt(), R.drawable.g_bixby),
        Feature("translate", "Translate", 0xFF616BD5.toInt(), R.drawable.g_translate),
        Feature("magnify", "Magnify", 0xFF00A266.toInt(), R.drawable.g_magnify),
        Feature("glance", "Glance", 0xFF18A80C.toInt(), R.drawable.ic_f_glance)
    )

    val samsungApps: List<Feature> = listOf(
        Feature("penup", "PENUP", 0, R.drawable.i_penup, true),
        Feature("ar_doodle", "AR Doodle", 0, R.drawable.i_ar_doodle, true)
    )

    fun byId(id: String): Feature? =
        all.firstOrNull { it.id == id } ?: samsungApps.firstOrNull { it.id == id }
}
