package com.aircmd.clone

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.drawable.ColorDrawable
import android.view.View

/** Light/dark palette. Dark values come from Samsung's own dark theme colors. */
class AppColors(val dark: Boolean) {
    val page = if (dark) 0xFF010102.toInt() else 0xFFF6F6F6.toInt()
    val card = if (dark) 0xFF17171A.toInt() else 0xFFFCFCFF.toInt()
    val text = if (dark) 0xFFFCFCFF.toInt() else 0xFF010102.toInt()
    val text2 = if (dark) 0xFFCCCCCE.toInt() else 0xFF838383.toInt()
    val label = if (dark) 0xFFE4E4E7.toInt() else 0xFF454545.toInt()
    val panel = if (dark) 0xFF17171A.toInt() else 0xFFFCFCFC.toInt()
    val divider = if (dark) 0xFF3A3A3D.toInt() else 0x1F000000

    companion object {
        fun isDark(ctx: Context): Boolean = when (Prefs.theme(ctx)) {
            1 -> false
            2 -> true
            else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        }

        fun of(ctx: Context) = AppColors(isDark(ctx))

        fun styleWindow(act: Activity, c: AppColors) {
            act.window.statusBarColor = c.page
            act.window.navigationBarColor = c.page
            act.window.setBackgroundDrawable(ColorDrawable(c.page))
            var f = act.window.decorView.systemUiVisibility
            val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            f = if (c.dark) f and light.inv() else f or light
            act.window.decorView.systemUiVisibility = f
        }
    }
}
