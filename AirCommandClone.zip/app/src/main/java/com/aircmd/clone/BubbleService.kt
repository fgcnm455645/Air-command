package com.aircmd.clone

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.Toast
import kotlin.math.hypot

class BubbleService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var bubble: BubbleView? = null
    private var menu: MenuLike? = null
    private val handler = Handler(Looper.getMainLooper())
    private var idle = false
    private var moveAnim: ValueAnimator? = null
    private val goIdleRunnable = Runnable { goIdle() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForegroundCompat()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        addBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "reload") reload()
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        moveAnim?.cancel()
        menu?.dismiss()
        menu = null
        bubble?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        bubble = null
        super.onDestroy()
    }

    private fun scale(): Float = Prefs.bubbleScale(this) / 100f
    private fun winSize(): Int = (dp(81f) * scale()).toInt()
    private fun circleSize(): Int = (dp(48f) * scale()).toInt()

    private fun edgeX(right: Boolean): Int {
        val dm = resources.displayMetrics
        val circle = circleSize()
        val half = (winSize() - circle) / 2
        val margin = dp(4f)
        return if (right) dm.widthPixels - margin - circle - half else margin - half
    }

    // When idle the bubble shrinks, fades and slides partly off the screen edge.
    private fun idleX(right: Boolean): Int {
        val shift = (circleSize() * 0.4f).toInt()
        return if (right) edgeX(true) + shift else edgeX(false) - shift
    }

    private fun reload() {
        val v = bubble ?: return
        v.configure(Prefs.glow(this), scale())
        moveAnim?.cancel()
        idle = false
        v.alpha = 1f
        v.scaleX = 1f
        v.scaleY = 1f
        lp.width = winSize()
        lp.height = winSize()
        lp.x = edgeX(Prefs.bubbleRight(this))
        try {
            wm.updateViewLayout(v, lp)
        } catch (e: Exception) {
        }
        scheduleIdle()
    }

    private fun animateX(to: Int, dur: Long) {
        val v = bubble ?: return
        moveAnim?.cancel()
        val a = ValueAnimator.ofInt(lp.x, to)
        a.duration = dur
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener {
            lp.x = it.animatedValue as Int
            try {
                wm.updateViewLayout(v, lp)
            } catch (ex: Exception) {
            }
        }
        a.start()
        moveAnim = a
    }

    private fun scheduleIdle() {
        handler.removeCallbacks(goIdleRunnable)
        if (Prefs.idleHide(this)) handler.postDelayed(goIdleRunnable, 2500)
    }

    private fun goIdle() {
        val v = bubble ?: return
        if (menu != null || idle || !Prefs.idleHide(this)) return
        idle = true
        animateX(idleX(Prefs.bubbleRight(this)), 350)
        v.animate().alpha(0.5f).scaleX(0.72f).scaleY(0.72f).setDuration(350).start()
    }

    private fun wake() {
        handler.removeCallbacks(goIdleRunnable)
        val v = bubble ?: return
        if (idle) {
            idle = false
            animateX(edgeX(Prefs.bubbleRight(this)), 150)
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(150).start()
        }
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("bubble", "Air Command", NotificationManager.IMPORTANCE_MIN)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "bubble")
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("Air Command")
            .setContentText("Floating bubble is active")
            .setContentIntent(pi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun addBubble() {
        val size = winSize()
        val dm = resources.displayMetrics
        lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = edgeX(Prefs.bubbleRight(this))
        lp.y = Prefs.bubbleY(this, dm.heightPixels / 3)

        val v = BubbleView(this)
        v.configure(Prefs.glow(this), scale())
        v.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            var dragging = false

            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        val wasIdle = idle
                        wake()
                        downX = e.rawX
                        downY = e.rawY
                        startX = if (wasIdle) edgeX(Prefs.bubbleRight(this@BubbleService)) else lp.x
                        startY = lp.y
                        dragging = false
                        (view as BubbleView).press(true)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!dragging && hypot(dx, dy) > dp(15f)) {
                            dragging = true
                            moveAnim?.cancel()
                        }
                        if (dragging) {
                            lp.x = startX + dx.toInt()
                            lp.y = startY + dy.toInt()
                            try {
                                wm.updateViewLayout(view, lp)
                            } catch (ex: Exception) {
                            }
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        (view as BubbleView).press(false)
                        if (dragging) {
                            snap()
                        } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                            showMenu()
                        } else {
                            scheduleIdle()
                        }
                    }
                }
                return true
            }
        })
        wm.addView(v, lp)
        bubble = v
        scheduleIdle()
    }

    private fun snap() {
        val dm = resources.displayMetrics
        val right = lp.x + lp.width / 2 > dm.widthPixels / 2
        val minY = dp(24f)
        val maxY = maxOf(minY, dm.heightPixels - lp.height - dp(24f))
        lp.y = lp.y.coerceIn(minY, maxY)
        Prefs.setBubble(this, lp.y, right)
        animateX(edgeX(right), 220)
        scheduleIdle()
    }

    private fun showMenu() {
        if (menu != null) return
        val dm = resources.displayMetrics
        val right = lp.x + lp.width / 2 > dm.widthPixels / 2
        val style = Prefs.animStyle(this)
        val panelScale = Prefs.panelScale(this) / 100f
        val closed = {
            bubble?.visibility = View.VISIBLE
            menu = null
            scheduleIdle()
        }
        val m: MenuLike = if (style == 1) {
            FloatMenu(
                this, Prefs.items(this), right, lp.x + lp.width / 2, lp.y + lp.height / 2,
                Prefs.iconSize(this), panelScale, closed, { id -> handlePick(id) }
            )
        } else {
            MenuDialog(
                this, Prefs.items(this), right, lp.y + lp.height / 2,
                Prefs.iconSize(this), panelScale, closed, { id -> handlePick(id) }
            )
        }
        menu = m
        if (style == 0) bubble?.visibility = View.INVISIBLE
        try {
            m.show()
        } catch (e: Exception) {
            bubble?.visibility = View.VISIBLE
            menu = null
        }
    }

    private fun handlePick(id: String) {
        when {
            id == "__settings" -> {
                val i = Intent(this, MainActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
            id == "screen_write" && Prefs.target(this, id) == null -> {
                val i = Intent(this, ScreenWriteActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
            id.startsWith("app:") -> {
                val i = packageManager.getLaunchIntentForPackage(id.substring(4))
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                }
            }
            else -> launchTarget(id)
        }
    }

    private fun launchTarget(id: String) {
        val label = Features.byId(id)?.label ?: id
        val target = Targets.get(this, id)
        if (target == null) {
            Toast.makeText(this, "$label: choose an app in Settings", Toast.LENGTH_SHORT).show()
            return
        }
        val i = Targets.intentFor(this, target)
        if (i == null) {
            Toast.makeText(this, "$label: app not found", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "$label: can't open this app", Toast.LENGTH_SHORT).show()
        }
    }
}
