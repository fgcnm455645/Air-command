package com.aircmd.clone

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.Toast
import kotlin.math.hypot

class BubbleService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var bubble: BubbleView? = null
    private var menu: MenuDialog? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForegroundCompat()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        addBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        menu?.dismiss()
        menu = null
        bubble?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        bubble = null
        super.onDestroy()
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("bubble", "Air Command", NotificationManager.IMPORTANCE_MIN)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "bubble")
            .setSmallIcon(R.drawable.ic_pen)
            .setContentTitle("Air Command")
            .setContentText("Floating bubble is active")
            .setContentIntent(pi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // The original window is 81dp; the visible circle is 48dp, centered.
    private fun addBubble() {
        val size = dp(81f)
        val dm = resources.displayMetrics
        lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = edgeX(Prefs.bubbleRight(this))
        lp.y = Prefs.bubbleY(this, dm.heightPixels / 3)

        val v = BubbleView(this)
        v.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            var dragging = false

            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX
                        downY = e.rawY
                        startX = lp.x
                        startY = lp.y
                        dragging = false
                        (view as BubbleView).press(true)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!dragging && hypot(dx, dy) > dp(15f)) dragging = true
                        if (dragging) {
                            lp.x = startX + dx.toInt()
                            lp.y = startY + dy.toInt()
                            try {
                                wm.updateViewLayout(view, lp)
                            } catch (ex: Exception) {
                            }
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        (view as BubbleView).press(false)
                        if (dragging) {
                            snap()
                        } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                            showMenu()
                        }
                    }
                }
                return true
            }
        })
        wm.addView(v, lp)
        bubble = v
    }

    private fun edgeX(right: Boolean): Int {
        val dm = resources.displayMetrics
        val circle = dp(48f)
        val half = (dp(81f) - circle) / 2
        val margin = dp(4f)
        return if (right) dm.widthPixels - margin - circle - half else margin - half
    }

    private fun snap() {
        val v = bubble ?: return
        val dm = resources.displayMetrics
        val right = lp.x + lp.width / 2 > dm.widthPixels / 2
        val minY = dp(24f)
        val maxY = maxOf(minY, dm.heightPixels - lp.height - dp(24f))
        lp.y = lp.y.coerceIn(minY, maxY)
        val a = ValueAnimator.ofInt(lp.x, edgeX(right))
        a.duration = 220
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener {
            lp.x = it.animatedValue as Int
            try {
                wm.updateViewLayout(v, lp)
            } catch (ex: Exception) {
            }
        }
        a.start()
        Prefs.setBubble(this, lp.y, right)
    }

    private fun showMenu() {
        if (menu != null) return
        val dm = resources.displayMetrics
        val right = lp.x + lp.width / 2 > dm.widthPixels / 2
        val m = MenuDialog(
            this,
            Prefs.items(this),
            right,
            lp.y + lp.height / 2,
            onClosed = {
                bubble?.visibility = View.VISIBLE
                menu = null
            },
            onPick = { id -> handlePick(id) }
        )
        menu = m
        bubble?.visibility = View.INVISIBLE
        try {
            m.show()
        } catch (e: Exception) {
            bubble?.visibility = View.VISIBLE
            menu = null
        }
    }

    private fun handlePick(id: String) {
        when {
            id == "__settings" -> {
                val i = Intent(this, MainActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
            id.startsWith("app:") -> {
                val i = packageManager.getLaunchIntentForPackage(id.substring(4))
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                }
            }
            else -> {
                val label = Features.byId(id)?.label ?: id
                Toast.makeText(this, "$label (coming soon)", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
