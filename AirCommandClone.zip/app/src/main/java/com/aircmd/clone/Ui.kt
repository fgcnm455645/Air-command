package com.aircmd.clone

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable

fun Context.dp(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

/** Crops any app icon into a circle (adaptive icons are rendered through a circular mask). */
fun circularIcon(ctx: Context, src: Drawable, size: Int, whiteBacking: Boolean): Drawable {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val path = Path()
    path.addCircle(size / 2f, size / 2f, size / 2f, Path.Direction.CW)
    c.clipPath(path)
    if (src is AdaptiveIconDrawable) {
        val ext = (size * 0.25f).toInt()
        val bg = src.background
        val fg = src.foreground
        if (bg != null) {
            bg.setBounds(-ext, -ext, size + ext, size + ext)
            bg.draw(c)
        }
        if (fg != null) {
            fg.setBounds(-ext, -ext, size + ext, size + ext)
            fg.draw(c)
        }
    } else if (whiteBacking) {
        c.drawColor(0xFFFFFFFF.toInt())
        val inset = (size * 0.14f).toInt()
        src.setBounds(inset, inset, size - inset, size - inset)
        src.draw(c)
    } else {
        src.setBounds(0, 0, size, size)
        src.draw(c)
    }
    return BitmapDrawable(ctx.resources, bmp)
}

fun customIconFile(ctx: Context, id: String): java.io.File = java.io.File(ctx.filesDir, "ic_$id.png")

/** Icon the user picked from the gallery for a shortcut, cropped to a circle (null if none). */
fun customIcon(ctx: Context, id: String, size: Int): Drawable? {
    val f = customIconFile(ctx, id)
    if (!f.exists()) return null
    val bmp = BitmapFactory.decodeFile(f.absolutePath) ?: return null
    return circularIcon(ctx, BitmapDrawable(ctx.resources, bmp), size, false)
}

fun featureIcon(ctx: Context, f: Feature, size: Int): Drawable {
    customIcon(ctx, f.id, size)?.let { return it }
    if (f.raster) {
        return circularIcon(ctx, ctx.getDrawable(f.glyph)!!.mutate(), size, false)
    }
    val bg = GradientDrawable()
    bg.shape = GradientDrawable.OVAL
    bg.setColor(f.color)
    val glyph = ctx.getDrawable(f.glyph)!!.mutate()
    val ld = LayerDrawable(arrayOf(bg, glyph))
    val inset = (size * f.inset).toInt()
    ld.setLayerInset(1, inset, inset, inset, inset)
    return ld
}

class ItemInfo(val id: String, val label: String, val icon: Drawable)

object Items {
    fun resolve(ctx: Context, id: String, size: Int, circular: Boolean = true): ItemInfo? {
        if (id.startsWith("app:")) {
            val pkg = id.substring(4)
            return try {
                val pm = ctx.packageManager
                val label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                val raw = pm.getApplicationIcon(pkg)
                ItemInfo(id, label, if (circular) circularIcon(ctx, raw, size, true) else raw)
            } catch (e: Exception) {
                null
            }
        }
        val f = Features.byId(id) ?: return null
        return ItemInfo(id, f.label, featureIcon(ctx, f, size))
    }
}
