package com.aircmd.clone

import android.content.Context
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable

fun Context.dp(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun featureIcon(ctx: Context, f: Feature): Drawable {
    val bg = GradientDrawable()
    bg.shape = GradientDrawable.OVAL
    bg.setColor(f.color)
    val glyph = ctx.getDrawable(f.glyph)!!.mutate()
    val ld = LayerDrawable(arrayOf(bg, glyph))
    val inset = ctx.dp(9f)
    ld.setLayerInset(1, inset, inset, inset, inset)
    return ld
}

class ItemInfo(val id: String, val label: String, val icon: Drawable)

object Items {
    fun resolve(ctx: Context, id: String): ItemInfo? {
        if (id.startsWith("app:")) {
            val pkg = id.substring(4)
            return try {
                val pm = ctx.packageManager
                val label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                ItemInfo(id, label, pm.getApplicationIcon(pkg))
            } catch (e: Exception) {
                null
            }
        }
        val f = Features.byId(id) ?: return null
        return ItemInfo(id, f.label, featureIcon(ctx, f))
    }
}
