package com.aircmd.clone

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var c: AppColors
    private var darkAtBuild = false
    private lateinit var gridHost: LinearLayout
    private lateinit var panelHost: LinearLayout
    private lateinit var toggle: Switch
    private var binding = false
    private var appsCache: List<ItemInfo>? = null

    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun rounded(color: Int, radiusDp: Float): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        c = AppColors.of(this)
        darkAtBuild = c.dark
        AppColors.styleWindow(this, c)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(c.page)

        // Header: back chevron, title, settings button (top right)
        val header = LinearLayout(this)
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(12f), 0, dp(12f), 0)
        val back = ImageView(this)
        back.setImageResource(R.drawable.ic_back)
        back.setColorFilter(c.text)
        back.setPadding(dp(10f), dp(10f), dp(10f), dp(10f))
        back.setOnClickListener { finish() }
        header.addView(back, lp(dp(44f), dp(44f)))
        val title = TextView(this)
        title.text = "Shortcuts"
        title.textSize = 20f
        title.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        title.setTextColor(c.text)
        title.setPadding(dp(8f), 0, 0, 0)
        header.addView(title, lp(0, wrap, 1f))
        val gear = ImageView(this)
        gear.setImageResource(R.drawable.ic_gear)
        gear.setColorFilter(c.text)
        gear.setPadding(dp(10f), dp(10f), dp(10f), dp(10f))
        gear.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        header.addView(gear, lp(dp(44f), dp(44f)))
        root.addView(header, lp(match, dp(56f)))

        val body = LinearLayout(this)
        body.orientation = LinearLayout.HORIZONTAL

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.setPadding(dp(24f), 0, dp(8f), dp(24f))
        val cardLp = lp(match, wrap)
        cardLp.topMargin = dp(4f)
        left.addView(toggleCard(), cardLp)
        gridHost = LinearLayout(this)
        gridHost.orientation = LinearLayout.VERTICAL
        left.addView(gridHost, lp(match, wrap))
        scroll.addView(left)
        body.addView(scroll, lp(0, match, 1f))

        val pScroll = ScrollView(this)
        pScroll.isVerticalScrollBarEnabled = false
        pScroll.background = rounded(c.panel, 28f)
        panelHost = LinearLayout(this)
        panelHost.orientation = LinearLayout.VERTICAL
        panelHost.setPadding(dp(8f), dp(10f), dp(8f), dp(10f))
        pScroll.addView(panelHost)
        val pLp = lp(dp(96f), match)
        pLp.setMargins(dp(8f), dp(8f), dp(14f), dp(16f))
        body.addView(pScroll, pLp)

        root.addView(body, lp(match, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (AppColors.isDark(this) != darkAtBuild) {
            recreate()
            return
        }
        val on = Prefs.enabled(this) && Settings.canDrawOverlays(this)
        setToggle(on)
        if (on) startForegroundService(Intent(this, BubbleService::class.java))
        refresh()
    }

    private fun toggleCard(): View {
        val card = LinearLayout(this)
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(16f), dp(12f), dp(12f), dp(12f))
        card.background = rounded(c.card, 20f)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t1 = TextView(this)
        t1.text = "Floating bubble"
        t1.textSize = 16f
        t1.setTextColor(c.text)
        val t2 = TextView(this)
        t2.text = "Show the Air Command bubble"
        t2.textSize = 12f
        t2.setTextColor(c.text2)
        col.addView(t1, lp(wrap, wrap))
        col.addView(t2, lp(wrap, wrap))

        toggle = Switch(this)
        toggle.setOnCheckedChangeListener { _, on -> if (!binding) onToggle(on) }
        card.addView(col, lp(0, wrap, 1f))
        card.addView(toggle, lp(wrap, wrap))
        return card
    }

    private fun setToggle(v: Boolean) {
        binding = true
        toggle.isChecked = v
        binding = false
    }

    private fun onToggle(on: Boolean) {
        if (on) {
            if (!Settings.canDrawOverlays(this)) {
                setToggle(false)
                Toast.makeText(this, "Allow \"Display over other apps\" first", Toast.LENGTH_LONG).show()
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
                return
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            Prefs.setEnabled(this, true)
            startForegroundService(Intent(this, BubbleService::class.java))
        } else {
            Prefs.setEnabled(this, false)
            stopService(Intent(this, BubbleService::class.java))
        }
    }

    private fun sectionTitle(text: String, topDp: Float = 22f): View {
        val t = TextView(this)
        t.text = text
        t.textSize = 14f
        t.setTextColor(c.text2)
        t.setPadding(0, dp(topDp), 0, dp(8f))
        return t
    }

    private fun refresh() {
        val added = Prefs.items(this)
        val gridIcon = dp(44f)

        gridHost.removeAllViews()
        gridHost.addView(sectionTitle("S Pen features"), lp(match, wrap))
        addGrid(Features.all.mapNotNull { Items.resolve(this, it.id, gridIcon, true) }, added)
        gridHost.addView(sectionTitle("", 6f), lp(match, wrap))
        addGrid(Features.samsungApps.mapNotNull { Items.resolve(this, it.id, gridIcon, true) }, added)

        gridHost.addView(sectionTitle("All apps"), lp(match, wrap))
        val apps = appsCache ?: loadApps().also { appsCache = it }
        addGrid(apps, added)

        panelHost.removeAllViews()
        for (id in added) {
            val info = Items.resolve(this, id, gridIcon, true) ?: continue
            panelHost.addView(panelItem(info), lp(match, wrap))
        }
    }

    private fun loadApps(): List<ItemInfo> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { ItemInfo("app:" + it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
    }

    private fun addGrid(list: List<ItemInfo>, added: List<String>) {
        for (chunk in list.chunked(3)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (i in 0 until 3) {
                val info = chunk.getOrNull(i)
                if (info == null) {
                    row.addView(View(this), lp(0, 1, 1f))
                } else {
                    row.addView(cell(info, added.contains(info.id)), lp(0, wrap, 1f))
                }
            }
            gridHost.addView(row, lp(match, wrap))
        }
    }

    private fun cell(info: ItemInfo, isAdded: Boolean): View {
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER_HORIZONTAL
        cell.setPadding(0, dp(8f), 0, dp(8f))
        val iv = ImageView(this)
        iv.setImageDrawable(info.icon)
        cell.addView(iv, lp(dp(44f), dp(44f)))
        val tv = TextView(this)
        tv.text = info.label
        tv.textSize = 12.5f
        tv.gravity = Gravity.CENTER
        tv.maxLines = 2
        tv.setTextColor(c.label)
        tv.setPadding(dp(2f), dp(6f), dp(2f), 0)
        cell.addView(tv, lp(match, wrap))
        cell.alpha = if (isAdded) 0.35f else 1f
        cell.setOnClickListener {
            val cur = Prefs.items(this)
            if (!cur.contains(info.id)) {
                cur.add(info.id)
                Prefs.setItems(this, cur)
                refresh()
            }
        }
        return cell
    }

    private fun panelItem(info: ItemInfo): View {
        val f = FrameLayout(this)
        f.setPadding(0, dp(10f), 0, dp(10f))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        val iv = ImageView(this)
        iv.setImageDrawable(info.icon)
        col.addView(iv, lp(dp(44f), dp(44f)))
        val tv = TextView(this)
        tv.text = info.label
        tv.textSize = 11.5f
        tv.gravity = Gravity.CENTER
        tv.maxLines = 2
        tv.setTextColor(c.label)
        tv.setPadding(0, dp(5f), 0, 0)
        col.addView(tv, lp(match, wrap))
        f.addView(col, FrameLayout.LayoutParams(match, wrap))

        val badge = ImageView(this)
        badge.setImageResource(R.drawable.ic_badge_minus)
        val bLp = FrameLayout.LayoutParams(dp(18f), dp(18f), Gravity.TOP or Gravity.START)
        bLp.leftMargin = dp(10f)
        bLp.topMargin = dp(6f)
        f.addView(badge, bLp)

        f.setOnClickListener {
            val cur = Prefs.items(this)
            cur.remove(info.id)
            Prefs.setItems(this, cur)
            refresh()
        }
        return f
    }
}
