package com.aircmd.clone

import android.app.Dialog
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * The shortcut panel: frosted rounded panel, label on the left and a round icon on the right,
 * gear at the bottom-left and "Add" at the bottom-right (as in the reference screenshot).
 */
class MenuDialog(
    private val ctx: Context,
    private val ids: List<String>,
    private val dockRight: Boolean,
    private val centerY: Int,
    private val onClosed: () -> Unit,
    private val onPick: (String) -> Unit
) {
    private val dialog = Dialog(ctx, R.style.MenuDialog)

    fun show() {
        val dm = ctx.resources.displayMetrics
        val w = minOf((dm.widthPixels * 0.77f).toInt(), ctx.dp(330f))

        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(ctx.dp(20f), ctx.dp(12f), ctx.dp(20f), ctx.dp(10f))
        for (id in ids) {
            val info = Items.resolve(ctx, id) ?: continue
            root.addView(
                row(info),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        }
        root.addView(
            bottomRow(),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(root, ViewGroup.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT))
        dialog.setCanceledOnTouchOutside(true)
        dialog.setOnDismissListener { onClosed() }

        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val blur = Build.VERSION.SDK_INT >= 31 && wm.isCrossWindowBlurEnabled

        val bg = GradientDrawable()
        bg.cornerRadius = ctx.dp(26f).toFloat()
        bg.setColor(if (blur) 0xB8FCFCFF.toInt() else 0xF2FCFCFF.toInt())
        bg.setStroke(1, 0x3DA6A6A6)

        val win = dialog.window!!
        win.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        win.setBackgroundDrawable(bg)
        win.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)

        root.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val h = root.measuredHeight
        val margin = ctx.dp(10f)
        val minY = ctx.dp(40f)
        val maxY = maxOf(minY, dm.heightPixels - h - ctx.dp(40f))
        val p = win.attributes
        p.gravity = Gravity.TOP or Gravity.START
        p.x = if (dockRight) dm.widthPixels - w - margin else margin
        p.y = (centerY - h / 2).coerceIn(minY, maxY)
        p.width = w
        p.height = ViewGroup.LayoutParams.WRAP_CONTENT
        p.dimAmount = 0f
        win.attributes = p

        if (blur) {
            win.setBackgroundBlurRadius(ctx.dp(50f))
        }
        dialog.show()
    }

    fun dismiss() {
        if (dialog.isShowing) dialog.dismiss()
    }

    private fun row(info: ItemInfo): View {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL or (if (dockRight) Gravity.END else Gravity.START)
        r.setPadding(0, ctx.dp(8f), 0, ctx.dp(8f))
        r.isClickable = true

        val tv = TextView(ctx)
        tv.text = info.label
        tv.textSize = 14f
        tv.setTextColor(0xFF010102.toInt())
        tv.maxLines = 1

        val iv = ImageView(ctx)
        iv.setImageDrawable(info.icon)
        val ivLp = LinearLayout.LayoutParams(ctx.dp(46f), ctx.dp(46f))
        val tvLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val gap = ctx.dp(14f)
        if (dockRight) {
            tvLp.marginEnd = gap
            r.addView(tv, tvLp)
            r.addView(iv, ivLp)
        } else {
            ivLp.marginEnd = gap
            r.addView(iv, ivLp)
            r.addView(tv, tvLp)
        }
        r.setOnClickListener {
            dialog.dismiss()
            onPick(info.id)
        }
        return r
    }

    private fun bottomRow(): View {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, ctx.dp(6f), 0, ctx.dp(2f))

        val toSettings = View.OnClickListener {
            dialog.dismiss()
            onPick("__settings")
        }

        val gear = ImageView(ctx)
        gear.setImageResource(R.drawable.ic_gear)
        gear.setColorFilter(0xFF3A3A3C.toInt())
        gear.setOnClickListener(toSettings)
        r.addView(gear, LinearLayout.LayoutParams(ctx.dp(28f), ctx.dp(28f)))

        val spacer = View(ctx)
        r.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))

        val add = TextView(ctx)
        add.text = "Add"
        add.textSize = 14f
        add.setTextColor(0xFF010102.toInt())
        add.setOnClickListener(toSettings)
        val addLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        addLp.marginEnd = ctx.dp(14f)
        r.addView(add, addLp)

        val circle = ImageView(ctx)
        val cbg = GradientDrawable()
        cbg.shape = GradientDrawable.OVAL
        cbg.setColor(0xFF1C1C1E.toInt())
        circle.background = cbg
        circle.setImageResource(R.drawable.ic_plus)
        circle.setPadding(ctx.dp(7f), ctx.dp(7f), ctx.dp(7f), ctx.dp(7f))
        circle.setOnClickListener(toSettings)
        val cLp = LinearLayout.LayoutParams(ctx.dp(34f), ctx.dp(34f))
        cLp.marginEnd = ctx.dp(6f)
        r.addView(circle, cLp)
        return r
    }
}
