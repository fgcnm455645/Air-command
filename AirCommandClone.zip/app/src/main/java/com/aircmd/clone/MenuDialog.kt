package com.aircmd.clone

import android.app.Dialog
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * The shortcut panel ("Air Command" animation style). Panel/text colors, light and dark,
 * are the original app's values. Everything scales with the panel size setting.
 */
class MenuDialog(
    private val ctx: Context,
    private val ids: List<String>,
    private val dockRight: Boolean,
    private val centerY: Int,
    private val iconSizeDp: Int,
    private val scale: Float,
    private val onClosed: () -> Unit,
    private val onPick: (String) -> Unit
) : MenuLike {
    private val dialog = Dialog(ctx, R.style.MenuDialog)
    private val dark = AppColors.isDark(ctx)
    private val textColor = if (dark) 0xFFFAFAFF.toInt() else 0xFF010102.toInt()

    private val labelFactor = Prefs.labelSize(ctx) / 100f
    private val showLabels = Prefs.showLabels(ctx)

    private fun d(v: Float): Int = ctx.dp(v * scale)

    override fun show() {
        val dm = ctx.resources.displayMetrics
        val w = (minOf(dm.widthPixels * 0.77f, ctx.dp(330f).toFloat()) * scale).toInt()
        val animate = true

        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(d(20f), d(12f), d(20f), d(10f))
        val iconPx = d(iconSizeDp.toFloat())
        for (id in ids) {
            val info = Items.resolve(ctx, id, iconPx, true) ?: continue
            root.addView(
                row(info, iconPx),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        }
        root.addView(
            bottomRow(),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        if (animate) {
            for (i in 0 until root.childCount) root.getChildAt(i).alpha = 0f
        }

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(root, ViewGroup.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT))
        dialog.setCanceledOnTouchOutside(true)
        dialog.setOnDismissListener { onClosed() }

        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val blur = Build.VERSION.SDK_INT >= 31 && wm.isCrossWindowBlurEnabled

        val bg = GradientDrawable()
        bg.cornerRadius = d(26f).toFloat()
        val fill = if (blur) {
            if (dark) 0xCC3A3A3D else 0xCCFCFCFF
        } else {
            if (dark) 0xB3010102 else 0xE6FCFCFF
        }
        bg.setColor(fill.toInt())
        bg.setStroke(1, if (dark) 0x33CCCCCC else 0x3DA6A6A6)

        val win = dialog.window!!
        win.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        win.setBackgroundDrawable(bg)
        win.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)

        root.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val h = root.measuredHeight
        val margin = ctx.dp(10f)
        val minY = ctx.dp(40f)
        val maxY = maxOf(minY, dm.heightPixels - h - ctx.dp(40f))
        val p = win.attributes
        p.gravity = Gravity.TOP or Gravity.START
        p.x = if (dockRight) dm.widthPixels - w - margin else margin
        p.y = (centerY - h / 2).coerceIn(minY, maxY)
        p.width = w
        p.height = ViewGroup.LayoutParams.WRAP_CONTENT
        p.dimAmount = 0f
        win.attributes = p

        if (blur) {
            win.setBackgroundBlurRadius(ctx.dp(50f))
        }
        dialog.show()

        if (animate) {
            root.post {
                for (i in 0 until root.childCount) {
                    val v = root.getChildAt(i)
                    v.scaleX = 0.85f
                    v.scaleY = 0.85f
                    v.pivotX = if (dockRight) v.width.toFloat() else 0f
                    v.pivotY = v.height / 2f
                    v.animate()
                        .alpha(1f).scaleX(1f).scaleY(1f)
                        .setStartDelay(i * 35L)
                        .setDuration(220)
                        .setInterpolator(OvershootInterpolator(1.4f))
                        .start()
                }
            }
        }
    }

    override fun dismiss() {
        if (dialog.isShowing) dialog.dismiss()
    }

    private fun row(info: ItemInfo, iconPx: Int): View {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL or (if (dockRight) Gravity.END else Gravity.START)
        r.setPadding(0, d(8f), 0, d(8f))
        r.isClickable = true

        val tv = TextView(ctx)
        tv.text = info.label
        tv.textSize = maxOf(9f, 14f * scale * labelFactor)
        tv.setTextColor(textColor)
        tv.maxLines = 1

        val iv = ImageView(ctx)
        iv.setImageDrawable(info.icon)
        val ivLp = LinearLayout.LayoutParams(iconPx, iconPx)
        val tvLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val gap = d(14f)
        if (dockRight) {
            tvLp.marginEnd = gap
            if (showLabels) r.addView(tv, tvLp)
            r.addView(iv, ivLp)
        } else {
            ivLp.marginEnd = gap
            r.addView(iv, ivLp)
            if (showLabels) r.addView(tv, tvLp)
        }
        r.setOnClickListener {
            dialog.dismiss()
            onPick(info.id)
        }
        return r
    }

    private fun bottomRow(): View {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, d(6f), 0, d(2f))

        val toSettings = View.OnClickListener {
            dialog.dismiss()
            onPick("__settings")
        }

        val gear = ImageView(ctx)
        gear.setImageResource(R.drawable.ic_gear)
        gear.setColorFilter(if (dark) 0xFFFAFAFF.toInt() else 0xFF3A3A3C.toInt())
        gear.setOnClickListener(toSettings)
        r.addView(gear, LinearLayout.LayoutParams(d(28f), d(28f)))

        val spacer = View(ctx)
        r.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))

        val add = TextView(ctx)
        add.text = "Add"
        add.textSize = maxOf(9f, 14f * scale * labelFactor)
        add.visibility = if (showLabels) View.VISIBLE else View.GONE
        add.setTextColor(textColor)
        add.setOnClickListener(toSettings)
        val addLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        addLp.marginEnd = d(14f)
        r.addView(add, addLp)

        val circle = ImageView(ctx)
        val cbg = GradientDrawable()
        cbg.shape = GradientDrawable.OVAL
        cbg.setColor(if (dark) 0xFFE4E4E7.toInt() else 0xFF1C1C1E.toInt())
        circle.background = cbg
        circle.setImageResource(R.drawable.ic_plus)
        circle.setColorFilter(if (dark) 0xFF010102.toInt() else 0xFFFAFAFF.toInt())
        circle.setPadding(d(7f), d(7f), d(7f), d(7f))
        circle.setOnClickListener(toSettings)
        val cLp = LinearLayout.LayoutParams(d(34f), d(34f))
        cLp.marginEnd = d(6f)
        r.addView(circle, cLp)
        return r
    }
}
