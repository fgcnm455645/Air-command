package com.aircmd.clone

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * "Smart Touch" style. Items sit on an invisible circle around the bubble (30.5 degrees apart,
 * six visible, measured from the J5 Pro recording). With six or fewer items the arc stays still;
 * with more, swiping up/down turns the ring and items at the ends fade out.
 */
class FloatMenu(
    private val ctx: Context,
    private val ids: List<String>,
    private val dockRight: Boolean,
    private val centerX: Int,
    private val centerY: Int,
    private val iconSizeDp: Int,
    private val scale: Float,
    private val onClosed: () -> Unit,
    private val onPick: (String) -> Unit
) : MenuLike {
    private class Item(val view: LinearLayout, val w: Int, val h: Int, val iconCenterX: Float)

    private val dialog = Dialog(ctx, R.style.MenuDialog)
    private var closing = false
    private val dimMax = 0.58f
    private val visible = 6
    private val stepDeg = 30.5f
    private val items = ArrayList<Item>()
    private var scroll = 0f
    private var maxScroll = 0f
    private var openT = 0f
    private var radius = 0f
    private var cx = 0f
    private var cy = 0f
    private var iconPx = 0
    private var pxPerItem = 1f

    private fun d(v: Float): Int = ctx.dp(v * scale)

    private inner class Ring(c: Context) : FrameLayout(c) {
        private val slop = ViewConfiguration.get(c).scaledTouchSlop
        private var downY = 0f
        private var lastY = 0f
        private var dragging = false
        private var vt: VelocityTracker? = null
        private var snapAnim: ValueAnimator? = null

        override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
            if (maxScroll <= 0f) return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    snapAnim?.cancel()
                    downY = e.y
                    lastY = e.y
                    dragging = false
                    vt?.recycle()
                    vt = VelocityTracker.obtain()
                    vt?.addMovement(e)
                }
                MotionEvent.ACTION_MOVE -> {
                    vt?.addMovement(e)
                    if (!dragging && abs(e.y - downY) > slop) {
                        dragging = true
                        lastY = e.y
                        return true
                    }
                }
            }
            return dragging
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (vt == null) vt = VelocityTracker.obtain()
            vt?.addMovement(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = e.y
                    lastY = e.y
                    dragging = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!dragging && abs(e.y - downY) > slop) {
                        dragging = true
                        lastY = e.y
                    }
                    if (dragging && maxScroll > 0f) {
                        val dy = e.y - lastY
                        lastY = e.y
                        scroll = (scroll - dy / pxPerItem).coerceIn(0f, maxScroll)
                        applyLayout()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) {
                        vt?.computeCurrentVelocity(1000)
                        val vy = vt?.yVelocity ?: 0f
                        val target = (scroll - vy * 0.10f / pxPerItem).roundToInt()
                            .coerceIn(0, maxScroll.roundToInt())
                        snapTo(target.toFloat())
                    } else {
                        closeAnimated()
                    }
                    vt?.recycle()
                    vt = null
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (dragging) snapTo(scroll.roundToInt().toFloat())
                    vt?.recycle()
                    vt = null
                }
            }
            return true
        }

        private fun snapTo(target: Float) {
            snapAnim?.cancel()
            val a = ValueAnimator.ofFloat(scroll, target)
            a.duration = 220
            a.interpolator = DecelerateInterpolator()
            a.addUpdateListener {
                scroll = it.animatedValue as Float
                applyLayout()
            }
            a.start()
            snapAnim = a
        }
    }

    override fun show() {
        val dm = ctx.resources.displayMetrics
        iconPx = d(iconSizeDp.toFloat())
        radius = dm.widthPixels * 0.36f * scale

        val ring = Ring(ctx)
        for (id in ids) {
            val info = Items.resolve(ctx, id, iconPx, true) ?: continue
            addItem(ring, id, info.label, info.icon, false)
        }
        addItem(ring, "__settings", "Add", null, true)

        val n = items.size
        maxScroll = max(0, n - visible).toFloat()
        pxPerItem = radius * Math.toRadians(stepDeg.toDouble()).toFloat()

        val halfSpan = radius * sin(Math.toRadians(76.0)).toFloat() + iconPx
        val margin = ctx.dp(24f).toFloat()
        cx = centerX.toFloat()
        cy = if (dm.heightPixels > 2 * (halfSpan + margin)) {
            centerY.toFloat().coerceIn(halfSpan + margin, dm.heightPixels - halfSpan - margin)
        } else {
            dm.heightPixels / 2f
        }

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(
            ring,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        dialog.setOnDismissListener { onClosed() }

        val win = dialog.window!!
        win.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        win.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        win.addFlags(
            WindowManager.LayoutParams.FLAG_DIM_BEHIND or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )
        win.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        win.setDimAmount(0f)

        applyLayout()
        dialog.show()

        animateDim(0f, dimMax, 200L, null)
        val open = ValueAnimator.ofFloat(0f, 1f)
        open.duration = 380
        open.interpolator = DecelerateInterpolator()
        open.addUpdateListener {
            openT = it.animatedValue as Float
            applyLayout()
        }
        open.start()
    }

    private fun addItem(ring: FrameLayout, id: String, label: String, icon: android.graphics.drawable.Drawable?, isAdd: Boolean) {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.isClickable = true

        val tv = TextView(ctx)
        tv.text = label
        tv.textSize = max(11f, 14f * scale)
        tv.setTextColor(0xFFFFFFFF.toInt())
        tv.setShadowLayer(ctx.dp(3f).toFloat(), 0f, 0f, 0xAA000000.toInt())
        tv.maxLines = 1

        val iv = ImageView(ctx)
        if (isAdd) {
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(Color.TRANSPARENT)
            bg.setStroke(ctx.dp(2f), 0xFFFFFFFF.toInt())
            iv.background = bg
            iv.setImageResource(R.drawable.ic_plus)
            iv.setColorFilter(0xFFFFFFFF.toInt())
            val pad = (iconPx * 0.2f).toInt()
            iv.setPadding(pad, pad, pad, pad)
        } else {
            iv.setImageDrawable(icon)
        }
        val ivLp = LinearLayout.LayoutParams(iconPx, iconPx)
        val tvLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val gap = d(10f)
        if (dockRight) {
            tvLp.marginEnd = gap
            r.addView(tv, tvLp)
            r.addView(iv, ivLp)
        } else {
            ivLp.marginEnd = gap
            r.addView(iv, ivLp)
            r.addView(tv, tvLp)
        }
        r.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = r.measuredWidth
        val h = r.measuredHeight
        val iconCenterX = if (dockRight) w - iconPx / 2f else iconPx / 2f
        r.pivotX = iconCenterX
        r.pivotY = h / 2f
        r.setOnClickListener {
            dialog.dismiss()
            onPick(id)
        }
        ring.addView(r, FrameLayout.LayoutParams(w, h, Gravity.TOP or Gravity.START))
        items.add(Item(r, w, h, iconCenterX))
    }

    private fun ease(x: Float): Float = 1f - (1f - x) * (1f - x)

    private fun applyLayout() {
        val n = items.size
        if (n == 0) return
        val mid = (min(n, visible) - 1) / 2f
        val sign = if (dockRight) 1.0 else -1.0
        val base = if (dockRight) 180.0 else 0.0
        val total = 1f + 0.06f * (n - 1)
        for ((i, it) in items.withIndex()) {
            val off = i - scroll - mid
            val rad = Math.toRadians(base + sign * off * stepDeg)
            val tx = cx + radius * cos(rad).toFloat()
            val ty = cy - radius * sin(rad).toFloat()
            val fade = ((abs(off) * stepDeg - 78f) / 40f).coerceIn(0f, 1f)
            var a = 1f - fade
            var s = 1f - 0.35f * fade
            val rank = abs(i - (n - 1) / 2f)
            val pe = ease((openT * total - 0.06f * rank).coerceIn(0f, 1f))
            val px = cx + (tx - cx) * pe
            val py = cy + (ty - cy) * pe
            a *= pe
            s *= 0.4f + 0.6f * pe
            val v = it.view
            v.translationX = px - it.iconCenterX
            v.translationY = py - it.h / 2f
            v.alpha = a
            v.scaleX = s
            v.scaleY = s
            v.visibility = if (a <= 0.02f) View.INVISIBLE else View.VISIBLE
        }
    }

    private fun animateDim(from: Float, to: Float, dur: Long, end: (() -> Unit)?) {
        val win = dialog.window ?: return
        val a = ValueAnimator.ofFloat(from, to)
        a.duration = dur
        a.addUpdateListener { win.setDimAmount(it.animatedValue as Float) }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                end?.invoke()
            }
        })
        a.start()
    }

    private fun closeAnimated() {
        if (closing) return
        closing = true
        val a = ValueAnimator.ofFloat(openT, 0f)
        a.duration = 160
        a.addUpdateListener {
            openT = it.animatedValue as Float
            applyLayout()
        }
        a.start()
        animateDim(dimMax, 0f, 160L) { dismiss() }
    }

    override fun dismiss() {
        if (dialog.isShowing) dialog.dismiss()
    }
}
