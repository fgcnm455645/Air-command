package com.aircmd.clone

import android.animation.ValueAnimator
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * "Smart Touch" animation style: no panel. The screen dims and the items fly out one by one,
 * nearest to the bubble first (timing measured from the J5 Pro recording).
 */
class FloatMenu(
    private val ctx: Context,
    private val ids: List<String>,
    private val dockRight: Boolean,
    private val centerY: Int,
    private val iconSizeDp: Int,
    private val scale: Float,
    private val onClosed: () -> Unit,
    private val onPick: (String) -> Unit
) : MenuLike {
    private val dialog = Dialog(ctx, R.style.MenuDialog)
    private var closing = false
    private val rows = ArrayList<View>()
    private val dimMax = 0.62f

    private fun d(v: Float): Int = ctx.dp(v * scale)

    override fun show() {
        val dm = ctx.resources.displayMetrics
        val root = FrameLayout(ctx)
        root.setOnClickListener { closeAnimated() }

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val iconPx = d(iconSizeDp.toFloat())
        for (id in ids) {
            val info = Items.resolve(ctx, id, iconPx, true) ?: continue
            val r = row(info, iconPx)
            rows.add(r)
            col.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        val add = addRow(iconPx)
        rows.add(add)
        col.addView(add, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        for (r in rows) r.alpha = 0f

        col.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val h = col.measuredHeight
        val minY = ctx.dp(48f)
        val maxY = maxOf(minY, dm.heightPixels - h - ctx.dp(48f))
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or (if (dockRight) Gravity.END else Gravity.START)
        )
        lp.topMargin = (centerY - h / 2).coerceIn(minY, maxY)
        if (dockRight) lp.rightMargin = ctx.dp(18f) else lp.leftMargin = ctx.dp(18f)
        root.addView(col, lp)

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        dialog.setOnDismissListener { onClosed() }

        val win = dialog.window!!
        win.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        win.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        win.addFlags(
            WindowManager.LayoutParams.FLAG_DIM_BEHIND or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )
        win.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        win.setDimAmount(0f)
        dialog.show()

        animateDim(0f, dimMax, 200L, null)
        root.post {
            val colTop = col.top
            val order = rows.sortedBy { abs(colTop + it.top + it.height / 2 - centerY) }
            val shift = ctx.dp(28f).toFloat() * (if (dockRight) 1f else -1f)
            for ((rank, v) in order.withIndex()) {
                v.translationX = shift
                v.scaleX = 0.7f
                v.scaleY = 0.7f
                v.pivotX = if (dockRight) v.width.toFloat() else 0f
                v.pivotY = v.height / 2f
                v.animate()
                    .alpha(1f).translationX(0f).scaleX(1f).scaleY(1f)
                    .setStartDelay(rank * 32L)
                    .setDuration(170)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
            }
        }
    }

    private fun animateDim(from: Float, to: Float, dur: Long, end: (() -> Unit)?) {
        val win = dialog.window ?: return
        val a = ValueAnimator.ofFloat(from, to)
        a.duration = dur
        a.addUpdateListener { win.setDimAmount(it.animatedValue as Float) }
        a.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                end?.invoke()
            }
        })
        a.start()
    }

    private fun closeAnimated() {
        if (closing) return
        closing = true
        val shift = ctx.dp(20f).toFloat() * (if (dockRight) 1f else -1f)
        for (v in rows) {
            v.animate().alpha(0f).translationX(shift).setStartDelay(0).setDuration(120).start()
        }
        animateDim(dimMax, 0f, 140L) { dismiss() }
    }

    override fun dismiss() {
        if (dialog.isShowing) dialog.dismiss()
    }

    private fun row(info: ItemInfo, iconPx: Int): View {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, d(7f), 0, d(7f))
        r.isClickable = true

        val tv = TextView(ctx)
        tv.text = info.label
        tv.textSize = maxOf(11f, 14f * scale)
        tv.setTextColor(0xFFFFFFFF.toInt())
        tv.setShadowLayer(ctx.dp(3f).toFloat(), 0f, 0f, 0xAA000000.toInt())
        tv.maxLines = 1

        val iv = ImageView(ctx)
        iv.setImageDrawable(info.icon)
        val ivLp = LinearLayout.LayoutParams(iconPx, iconPx)
        val tvLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val gap = d(12f)
        if (dockRight) {
            tvLp.marginEnd = gap
            r.addView(tv, tvLp)
            r.addView(iv, ivLp)
        } else {
            ivLp.marginEnd = gap
            r.addView(iv, ivLp)
            r.addView(tv, tvLp)
        }
        r.setOnClickListener {
            dialog.dismiss()
            onPick(info.id)
        }
        return r
    }

    private fun addRow(iconPx: Int): View {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, d(7f), 0, d(7f))
        r.isClickable = true

        val tv = TextView(ctx)
        tv.text = "Add"
        tv.textSize = maxOf(11f, 14f * scale)
        tv.setTextColor(0xFFFFFFFF.toInt())
        tv.setShadowLayer(ctx.dp(3f).toFloat(), 0f, 0f, 0xAA000000.toInt())

        val circle = ImageView(ctx)
        val cbg = GradientDrawable()
        cbg.shape = GradientDrawable.OVAL
        cbg.setColor(0xFF1C1C1E.toInt())
        circle.background = cbg
        circle.setImageResource(R.drawable.ic_plus)
        circle.setColorFilter(0xFFFAFAFF.toInt())
        val pad = (iconPx * 0.2f).toInt()
        circle.setPadding(pad, pad, pad, pad)
        val cLp = LinearLayout.LayoutParams(iconPx, iconPx)
        val tvLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val gap = d(12f)
        if (dockRight) {
            tvLp.marginEnd = gap
            r.addView(tv, tvLp)
            r.addView(circle, cLp)
        } else {
            cLp.marginEnd = gap
            r.addView(circle, cLp)
            r.addView(tv, tvLp)
        }
        r.setOnClickListener {
            dialog.dismiss()
            onPick("__settings")
        }
        return r
    }
}
