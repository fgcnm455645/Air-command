package com.aircmd.clone

interface MenuLike {
    fun show()
    fun dismiss()
}
